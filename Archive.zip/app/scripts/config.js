'use strict';

//window.APP_KEY = 'kid_SJSt9W_S';
//window.APP_SECRET = '695d6e3dae484e7e96509479ff96e926';
// window.APP_KEY = 'kid_H1IXosZH';
// window.APP_SECRET = '1b8c54d103e2454ab1494caebebd8426';
window.APP_KEY = 'kid_byGoHmnX2';
window.APP_SECRET = '9b8431f34279434bbedaceb2fe6b8fb5';
window.API_HOSTNAME = 'https://kcs.kinvey.com';
window.MIC_HOSTNAME = 'https://auth.kinvey.com';
window.REDIRECT_URI = 'http://localhost:9000/callback';
