Kinvey.User.logout().then(function() {
  // User is logged out.
});
